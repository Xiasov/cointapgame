# Монетный тап

Игра целиком лежит в одном файле `index.html`. Её можно открыть двойным щелчком в браузере (ПК и телефон). Прогресс сохраняется на устройстве.

Файлы `.exe` и `.apk` собираются на вашем компьютере из этого же файла.

## Windows (.exe)

Нужен установленный Node.js (https://nodejs.org). В папке проекта выполните:

```
npm install --save-dev electron electron-builder
npm start          # проверить, что окно открывается
npm run build      # собрать .exe
```

Готовый портативный `.exe` появится в папке `dist`. Собирать лучше на самой Windows.

## Android (.apk)

Нужны Node.js и Android Studio (https://developer.android.com/studio).

```
npm install @capacitor/core @capacitor/cli @capacitor/android
mkdir www
copy index.html www\index.html        (на Mac/Linux: cp index.html www/index.html)
npx cap init "Монетный тап" com.example.cointap --web-dir=www
npx cap add android
npx cap sync
npx cap open android
```

В Android Studio откройте меню Build → Build Bundle(s) / APK(s) → Build APK(s). Готовый файл `app-debug.apk` лежит в `android/app/build/outputs/apk/debug`. Его можно отправить на телефон и установить, разрешив установку из неизвестных источников.

## Без сборки

Если нужен просто значок на экране телефона: откройте страницу игры в Chrome и выберите «Добавить на главный экран».
